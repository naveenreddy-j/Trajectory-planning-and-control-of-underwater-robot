function sd = AUVEOM(t, s, controlhandle, trajhandle, parameters)
current_state = stToQd(s);
des_st = trajhandle(t, current_state);
[Force, Moment] = controlhandle(t, current_state, des_st, parameters);
sd = AUVEOM_readonly(t, s, Force, Moment, parameters);
end
