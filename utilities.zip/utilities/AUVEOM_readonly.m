function sd = AUVEOM_readonly(t, s, Force, Moment, parameters)
A = [0.25,                      0, -.5/parameters.arm_length;
     0.25,  .5/parameters.arm_length,                      0;
     .25,                      0,  .5/parameters.arm_length;
     .25, -.5/parameters.arm_length,                      0];
prop_thrusts = A*[Force;Moment(1:2)];
prop_thrusts_clamped = max(min(prop_thrusts, parameters.maxF/4), parameters.minF/4);
B = [                 1,                 1,                 1,                  1;
                      0, parameters.arm_length,                 0, -parameters.arm_length;
     -parameters.arm_length,                 0, parameters.arm_length,                 0];
Force = B(1,:)*prop_thrusts_clamped;
Moment = [B(2:3,:)*prop_thrusts_clamped; Moment(3)];
% Assign states
x = s(1);
y = s(2);
z = s(3);
xd = s(4);
yd = s(5);
zd = s(6);
qW = s(7);
qX = s(8);
qY = s(9);
qZ = s(10);
p = s(11);
q = s(12);
r = s(13);
quat = [qW; qX; qY; qZ];
bRw = QuatTorotat(quat);
wRb = bRw';
% acceleration
aclrt = 1 / parameters.mass * (wRb * [0; 0; Force] - [0; 0; parameters.mass * parameters.gr])
% Angular velocity
K_quat = 1; %this enforces the magnitude 1 constraint for the quaternion
quaterror = 1 - (qW^2 + qX^2 + qY^2 + qZ^2);
qd = -1/2*[0, -p, -q, -r;...
             p,  0, -r,  q;...
             q,  r,  0, -p;...
             r, -q,  p,  0] * quat + K_quat*quaterror * quat;
% Angular acceleration
omg = [p;q;r];
pqrd   = parameters.invI * (Moment - cross(omg, parameters.I*omg));
% Assemble sd
sd = zeros(13,1);
sd(1)  = xd;
sd(2)  = yd;
sd(3)  = zd;
sd(4)  = aclrt(1);
sd(5)  = aclrt(2);
sd(6)  = aclrt(3);
sd(7)  = qd(1);
sd(8)  = qd(2);
sd(9)  = qd(3);
sd(10) = qd(4);
sd(11) = pqrd(1);
sd(12) = pqrd(2);
sd(13) = pqrd(3);
end
