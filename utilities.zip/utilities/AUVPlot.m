classdef AUVPlot < handle
    properties (SetAccess = public)
        k = 0;
        qn;             % AUV number
        time = 0;       % time
        st;          % st
        desired_st;      % desried st [x; y; z; xd; yd; zd];
        rotat;            % rotat matrix body to world

        color;          % color of AUV
        wingspan;       % wingspan
        height;         % height of AUV
        motor;          % motor position

        st_hist        % position history
        st_des_hist;   % desired position history
        time_hist;      % time history
        max_iter;       % max iteration
    end
    properties (SetAccess = private)
        h_3d
        h_m13;  % motor 1 and 3 handle
        h_m24;  % motor 2 and 4 handle
        h_qz;   % z axis of AUV handle
        h_qn;   % AUV number handle
        h_position_hist;     % position history handle
        h_position_des_hist; % desired position history handle
        text_dist;  % distance of AUV number to AUV
    end
    methods
        % Constructor
        function Q = AUVPlot(qn, st, wingspan, height, color, max_iter, h_3d)
            Q.qn = qn;
            Q.st = st;
            Q.wingspan = wingspan;
            Q.color = color;
            Q.height = height;
            Q.rotat = QuatTorotat(Q.st(7:10));
            Q.motor = AUV_position(Q.st(1:3), Q.rotat, Q.wingspan, Q.height);
            Q.text_dist = Q.wingspan / 3;
            Q.desired_st = Q.st(1:6);

            Q.max_iter = max_iter;
            Q.st_hist = zeros(6, max_iter);
            Q.st_des_hist = zeros(6, max_iter);
            Q.time_hist = zeros(1, max_iter);

            % Initialize plot handle
            if nargin < 7, h_3d = gca; end
            Q.h_3d = h_3d;
            hold(Q.h_3d, 'on')
            Q.h_position_hist = plot3(Q.h_3d, Q.st(1), Q.st(2), Q.st(3), 'r.');
            Q.h_position_des_hist = plot3(Q.h_3d, Q.desired_st(1), Q.desired_st(2), Q.desired_st(3), 'b.');
            Q.h_m13 = plot3(Q.h_3d, ...
                Q.motor(1,[1 3]), ...
                Q.motor(2,[1 3]), ...
                Q.motor(3,[1 3]), ...
                '-ko', 'MarkerFaceColor', Q.color, 'MarkerSize', 5);
            Q.h_m24 = plot3(Q.h_3d, ...
                Q.motor(1,[2 4]), ...
                Q.motor(2,[2 4]), ...
                Q.motor(3,[2 4]), ...
                '-ko', 'MarkerFaceColor', Q.color, 'MarkerSize', 5);
            Q.h_qz = plot3(Q.h_3d, ...
                Q.motor(1,[5 6]), ...
                Q.motor(2,[5 6]), ...
                Q.motor(3,[5 6]), ...
                'Color', Q.color, 'LineWidth', 2);
            Q.h_qn = text(...
                Q.motor(1,5) + Q.text_dist, ...
                Q.motor(2,5) + Q.text_dist, ...
                Q.motor(3,5) + Q.text_dist, num2str(qn));
            hold(Q.h_3d, 'off')
        end

        % Update AUV st
        function UpdateAUVst(Q, st, time)
            Q.st = st;
            Q.time = time;
            Q.rotat = QuatTorotat(st(7:10))'; % Q.rotat needs to be body-to-world
        end

        % Update desired AUV st
        function UpdateDesiredAUVst(Q, desired_st)
            Q.desired_st = desired_st;
        end

        % Update AUV history
        function UpdateAUVHist(Q)
            Q.k = Q.k + 1;
            Q.time_hist(Q.k) = Q.time;
            Q.st_hist(:,Q.k) = Q.st(1:6);
            Q.st_des_hist(:,Q.k) = Q.desired_st(1:6);
        end

        % Update motor position
        function UpdateMotorposition(Q)
            Q.motor = AUV_position(Q.st(1:3), Q.rotat, Q.wingspan, Q.height);
        end

        % Truncate history
        function TruncateHist(Q)
            Q.time_hist = Q.time_hist(1:Q.k);
            Q.st_hist = Q.st_hist(:, 1:Q.k);
            Q.st_des_hist = Q.st_des_hist(:, 1:Q.k);
        end

        % Update AUV plot
        function UpdateAUVPlot(Q, st, desired_st, time)
            Q.UpdateAUVst(st, time);
            Q.UpdateDesiredAUVst(desired_st);
            Q.UpdateAUVHist();
            Q.UpdateMotorposition();
            set(Q.h_m13, ...
                'XData', Q.motor(1,[1 3]), ...
                'YData', Q.motor(2,[1 3]), ...
                'ZData', Q.motor(3,[1 3]));
            set(Q.h_m24, ...
                'XData', Q.motor(1,[2 4]), ...
                'YData', Q.motor(2,[2 4]), ...
                'ZData', Q.motor(3,[2 4]));
            set(Q.h_qz, ...
                'XData', Q.motor(1,[5 6]), ...
                'YData', Q.motor(2,[5 6]), ...
                'ZData', Q.motor(3,[5 6]))
            set(Q.h_qn, 'position', ...
                [Q.motor(1,5) + Q.text_dist, ...
                Q.motor(2,5) + Q.text_dist, ...
                Q.motor(3,5) + Q.text_dist]);
            set(Q.h_position_hist, ...
                'XData', Q.st_hist(1,1:Q.k), ...
                'YData', Q.st_hist(2,1:Q.k), ...
                'ZData', Q.st_hist(3,1:Q.k));
            set(Q.h_position_des_hist, ...
                'XData', Q.st_des_hist(1,1:Q.k), ...
                'YData', Q.st_des_hist(2,1:Q.k), ...
                'ZData', Q.st_des_hist(3,1:Q.k));
            drawnow;
        end
    end

end
