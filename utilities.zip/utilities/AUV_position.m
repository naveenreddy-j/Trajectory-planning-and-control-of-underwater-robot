function [ AUV ] = AUV_position( position, rotat, L, H )
if nargin < 4; H = 0.05; end
wHb   = [rotat position(:); 0 0 0 1]; 
AUVBodyFrame  = [L 0 0 1; 0 L 0 1; -L 0 0 1; 0 -L 0 1; 0 0 0 1; 0 0 H 1]';
AUVWorldFrame = wHb * AUVBodyFrame;
AUV           = AUVWorldFrame(1:3, :);
end
