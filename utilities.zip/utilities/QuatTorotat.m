function R = QuatTorotat(q)
q = q./sqrt(sum(q.^2));
qh(1,2) = -q(4);
qh(1,3) = q(3);
qh(2,3) = -q(2);
qh(2,1) = q(4);
qh(3,1) = -q(3);
qh(3,2) = q(2);
R = eye(3) + 2*qh*qh + 2*q(1)*qh;
end