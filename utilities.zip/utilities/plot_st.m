function [ h_fig ] = plot_st( h_fig, st, time, name, type, view )
if nargin < 6, view = 'sep'; end
if nargin < 5, type = 'vic'; end
if nargin < 4, name = 'position'; end
if isempty(h_fig), h_fig = figure(); end
line_width = 2;
switch type
    case 'vic'
        line_color = 'r';
    case 'des'
        line_color = 'b';
    case 'est'
        line_color = 'g';
end
switch name
    case 'position'
        labels = {'x [m]', 'y [m]', 'z [m]'};
    case 'velocity'
        labels = {'xd [m/s]', 'yd [m/s]', 'zd [m/s]'};
    case 'euler'
        labels = {'roll [rad]', 'pitch [rad]', 'yw [rad]'};
end

figure(h_fig)
if strcmp(view, 'sep')
    for i = 1:3
        subplot(3, 1, i)
        hold on
        plot(time, st(i,:), line_color, 'LineWidth', line_width);
        hold off
        xlim([time(1), time(end)])
        grid on
        xlabel('time [s]')
        ylabel(labels{i})
    end
elseif strcmp(view, '3d')
    hold on
    plot3(st(1,:), st(2,:), st(3,:), line_color, 'LineWidth', line_width)
    hold off
    grid on
    xlabel(labels{1});
    ylabel(labels{2});
    zlabel(labels{3});
end
end
