function [qd] = stToQd(x)
%current st
qd.position = x(1:3);
qd.velocity = x(4:6);
rotat = QuatTorotat(x(7:10)');
[phi, theta, yw] = RotatToRPY_ZXY(rotat);
qd.rotat = [phi; theta; yw];
qd.omg = x(11:13);
end
