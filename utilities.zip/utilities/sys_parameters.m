function parameters = sys_parameters()
m = 10; % kg
g = 9.81; % m/s^2
I = [0.00025,   0,          0;
     0,         0.000232,   0;
     0,   0,          0.0003738];
parameters.mass = m;
parameters.I    = I;
parameters.invI = inv(I);
parameters.gr = g;
parameters.arm_length = 0.45; % m
parameters.minF = 0.0;
parameters.maxF = 3.0*m*g;
end
