function [ terminate_cond ] = terminate_check( x, time, stop, position_tol, velocity_tol, time_tol)
% Initialize
position_check = true;
velocity_check = true;
position_col_check = zeros(1, 3);

position_check = position_check && (norm(x(1:3) - stop) < position_tol);
velocity_check = velocity_check && (norm(x(4:6)) < velocity_tol);
position_col_check(1,:) = x(1:3)';

%simulation time
time_check = time > time_tol;

if (position_check && velocity_check)
    terminate_cond = 1; %Goal reached
elseif time_check
    terminate_cond = 2; %Goal not reached
else
    terminate_cond = 0;
end

end
